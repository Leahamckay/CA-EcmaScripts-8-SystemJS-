export function run(params) {
  console.log("📥 Intake flow started");
  console.log("Intake notes:", params.notes);
}