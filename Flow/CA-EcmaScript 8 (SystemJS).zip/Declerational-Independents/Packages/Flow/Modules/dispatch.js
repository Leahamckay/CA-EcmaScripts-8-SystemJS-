export function run(params) {
  console.log("🚚 Dispatch flow started");
  console.log("Payload:", params.payload);
  console.log("Priority:", params.priority);
}