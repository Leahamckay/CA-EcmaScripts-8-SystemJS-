System.config({
  baseURL: '/',
  packages: {
    "packages": {
      defaultExtension: "js"
    }
  },
  map: {
    "flowModules": "packages/flowModules"
  }
});