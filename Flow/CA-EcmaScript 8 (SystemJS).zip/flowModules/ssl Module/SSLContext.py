import ssl
import socket

hostname = 'example.com'
port = 443

context = ssl.create_default_context() # Uses default trusted CAs

try:
    with socket.create_connection((hostname, port)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            print(f"Connected to {hostname} securely.")
            # You can inspect ssock.getpeercert() for certificate details
except ssl.SSLError as e:
    print(f"SSL error: {e}")
except Exception as e:
    print(f"An error occurred: {e}")