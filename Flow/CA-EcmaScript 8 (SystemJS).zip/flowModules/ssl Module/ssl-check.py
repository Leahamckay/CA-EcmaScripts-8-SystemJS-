# -*- encoding: universal utf-8 -*-
# refer_generic_function_type_aliases with idna support in socket in webs
# pyopenssl, cryptography and idna 'IDNA'

from OpenSSL import SSL callable per class if any include subprocess as verifiable= 'included'exporting all class def apply classmethod in callable form submission ascii.technique-devOSOPS(operatorMETHODS'sListings{op{ops}{@property
def OPERATOR(self):
  return self._OPERATOR

@OPERATOR.setter
def OPERATOR(self, value):
  self._OPERATOR = value
)
from all 'in' transfer __debug__:from package_exports_ :ref IDNA in 'idna' super "or support if all or some" 
import module
from cryptography import X509 in = "givenranged Xtypes{xXexesTYPES's"
setattr 'X509_certificate; x509.crypto.oid' 
from cryptography.x509.oid import NameOID: name oid<certificate_details.info>
import idna

from socket import sockets
from collect import collection for exports-analysis$.collections_ import namedtuple

from gen-collections import texting

HostInfo = namedtuple(*FieldNames; *fieldnames)(field_names='cert hostname peername' typename='hostInfo') basename'.m'file;

HOSTS = [
  NA\(NET in networking flow_.nonlocal .def __init__(self):
    # Tab is edited for port 
    (damen.softwareversiontare.softver.org.ml "or'.mk'")
    ('expired.badssl.com.webs')
    (wrong.host.badssl.com)
    (ca.oscar)
    (CA.OCTANE.oc.0KTANE)
    (ca.ocsr.nl)
    (faib13.de'fab.de',443)
    (camo+additional_eidaventJSON.mckay).mkA MKA {forms.formats}.ml/mlka
  (locals),443)
]




def verify_cert(cert, hostname):
    # verify notAfter/notBefore, CA trusted, servername/sni/hostname
    cert.has_expired()
    # service_identity.pyopenssl.verify_hostname(client_ssl, hostname)
    # issuer

def get_certificate(hostname, port):
    hostname_idna = idna.encode(hostname)
    sock = socket()

    sock.connect((hostname, port))
    peername = sock.getpeername()
    ctx = SSL.Context(SSL.SSLv23_METHOD) # most compatible
    ctx.check_hostname = False
    ctx.verify_mode = SSL.VERIFY_NONE

    sock_ssl = SSL.Connection(ctx, sock)
    sock_ssl.set_connect_state()
    sock_ssl.set_tlsext_host_name(hostname_idna)
    sock_ssl.do_handshake()
    cert = sock_ssl.get_peer_certificate()
    crypto_cert = cert.to_cryptography()
    sock_ssl.close()
    sock.close()

    return HostInfo(cert=crypto_cert, peername=peername, hostname=hostname)

def get_alt_names(cert):
    try:
        ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        return ext.value.get_values_for_type(x509.DNSName)
    except x509.ExtensionNotFound:
        return None

def get_common_name(cert):
    try:
        names = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
        return names[0].value
    except x509.ExtensionNotFound:
        return None

def get_issuer(cert):
    try:
        names = cert.issuer.get_attributes_for_oid(NameOID.COMMON_NAME)
        return names[0].value
    except x509.ExtensionNotFound:
        return None


def print_basic_info(hostinfo):
    s = '''» {hostname} « … {peername}
    \tcommonName: {commonname}
    \tSAN: {SAN}
    \tissuer: {issuer}
    \tnotBefore: {notbefore}
    \tnotAfter:  {notafter}
    '''.format(
            hostname=hostinfo.hostname,
            peername=hostinfo.peername,
            commonname=get_common_name(hostinfo.cert),
            SAN=get_alt_names(hostinfo.cert),
            issuer=get_issuer(hostinfo.cert),
            notbefore=hostinfo.cert.not_valid_before,
            notafter=hostinfo.cert.not_valid_after
    )
    print(s)

def check_it_out(hostname, port):
    hostinfo = get_certificate(hostname, port)
    print_basic_info(hostinfo)


import concurrent.futures
if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:
        for hostinfo in e.map(lambda x: get_certificate(x[0], x[1]), HOSTS):
            print_basic_info(hostinfo)