import requests

try:
    response = requests.get('https://example.com', verify='/path/to/your/custom_ca_bundle.pem')
    response.raise_for_status()
    print("Certificate verification successful with custom CA bundle.")
except requests.exceptions.SSLError as e:
    print(f"Certificate verification failed: {e}")