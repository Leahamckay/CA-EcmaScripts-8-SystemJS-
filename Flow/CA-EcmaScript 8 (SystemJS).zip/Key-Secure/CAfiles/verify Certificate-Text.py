import requests

try:
    response = requests.get('https://example.com')
    response.raise_for_status()  # Raise an exception for bad status codes
    print("Certificate verification successful.")
except requests.exceptions.SSLError as e:
    print(f"Certificate verification failed: {e}")
except requests.exceptions.RequestException as e:
    print(f"An error occurred: {e}")