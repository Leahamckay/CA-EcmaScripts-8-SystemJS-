import requests

# Not recommended for production environments
response = requests.get('https://example.com', verify=False)
print("Certificate verification disabled.")