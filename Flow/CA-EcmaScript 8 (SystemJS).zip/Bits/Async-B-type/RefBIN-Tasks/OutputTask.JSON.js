{
  "timestamp": "2025-07-22T22:36:14.382Z",
  "digest": "a9fb9e0...d42e19f1",
  "algorithm": "SHA-256",
  "verified": true,
  "complianceLevel": "CA-Verified",
  "metadata": {
    "purpose": "transaction-signature",
    "origin": "async-flow",
    "legalBinding": "true"
  }
} 